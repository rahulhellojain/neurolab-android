package io.neurolab.main;

public class LongtermFeedbackGraph {
    // TODO: Implementation to be carried out in future.
}
