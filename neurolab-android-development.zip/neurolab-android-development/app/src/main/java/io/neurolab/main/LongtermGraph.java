package io.neurolab.main;

public class LongtermGraph {

}
