package io.neurolab.interfaces;

public interface Recorder {

    void write(long timestamp, String data);

}
