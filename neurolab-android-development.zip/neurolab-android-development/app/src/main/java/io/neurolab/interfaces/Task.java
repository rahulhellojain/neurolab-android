package io.neurolab.interfaces;

public interface Task
{
    void init();
    void run();
    void stop();

}
