package io.neurolab.gui;

public class SpectralViewPanel {
    // public setValues in future development if needed.
}
