package io.neurolab.interfaces;

import java.util.List;

public interface DataReceiver {

    void appendData(List<double[]> data);

}
